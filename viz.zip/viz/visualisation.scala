// Databricks notebook source
// Chargement du fichier
val lines = spark.sparkContext.textFile("dbfs:/FileStore/*.txt")

// Filtrer les lignes contenant le mot "copyright" pour marquer la fin d'un livre
val bookBoundaries = lines.filter(_.toLowerCase.contains("copyright"))

// Compter le nombre de livres
val bookCount = bookBoundaries.count()

println(s"Nombre de livres: $bookCount")


// COMMAND ----------

import org.apache.spark.sql.functions._

// Chargement des fichiers texte contenant les données sur les livres
val filesRDD = spark.sparkContext.wholeTextFiles("dbfs:/FileStore/*.txt")

// Concaténer le contenu des fichiers pour extraire les mots-clés
val keywordsDF = filesRDD.toDF("dbfs:/FileStore/", "text").select("text")

// Tokenisation des mots
val wordsDF = keywordsDF.select(explode(split(lower(regexp_replace(col("text"), "[.,;:!?]", "")), "\\s+")).alias("word"))

// Filtrer les mots-clés vides ou peu significatifs
val filteredWordsDF = wordsDF.filter(length(col("word")) > 2)

// Compter la fréquence de chaque mot-clé
val keywordCounts = filteredWordsDF.groupBy("word").count().orderBy(desc("count"))

// Afficher les mots-clés les plus populaires
display(keywordCounts)

// COMMAND ----------

// Convertir le DataFrame Spark en DataFrame R pour l'affichage du graphe
val keywordCountsR = keywordCounts.select("word", "count").as[(String, Long)].collect()

// Extraire les mots-clés et leurs fréquences
val keywords = keywordCountsR.map(_._1)
val counts = keywordCountsR.map(_._2)

// Afficher les 20 premiers mots-clés les plus populaires
val topKeywords = keywords.take(20)
val topCounts = counts.take(20)

// Créer un DataFrame à partir des données des mots-clés et de leurs fréquences
val topKeywordsDF = spark.createDataFrame(topKeywords.zip(topCounts)).toDF("word", "count")

// Afficher le graphe en barres
topKeywordsDF.createOrReplaceTempView("topKeywords")
display(spark.sql("SELECT * FROM topKeywords"))


// COMMAND ----------

import org.apache.spark.sql.functions._

// Chargement des fichiers texte contenant les données sur les livres
val filesRDD = spark.sparkContext.wholeTextFiles("dbfs:/FileStore/*.txt")

// Calculer le nombre de mots dans chaque fichier
val wordCountDF = filesRDD.toDF("path", "content")
  .withColumn("word_count", size(split($"content", "\\s+")))

// Extraire le nom de fichier à partir du chemin
val extractFileName = udf((path: String) => new java.io.File(path).getName)

// Ajouter le nom de fichier à partir du chemin complet
val fileWordCountDF = wordCountDF.withColumn("file_name", extractFileName($"path"))

// Calculer la moyenne des mots pour chaque fichier
val averageWordCountDF = fileWordCountDF.groupBy("file_name").agg(avg("word_count").alias("average_word_count")).orderBy("file_name")

// Afficher le résultat
display(averageWordCountDF)


// COMMAND ----------



// COMMAND ----------

// dbutils.fs.rm("dbfs:/FileStore/BOOK_2000_ROWS_2.txt")
